// script.js

// Open product modal
function openModal(title, price, imgSrc) {
  document.getElementById('modal').classList.remove('hidden');
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-price').textContent = price;
  document.getElementById('modal-img').src = imgSrc;
}

// Close modal
function closeModal() {
  document.getElementById('modal').classList.add('hidden');
}

// Theme toggle
const toggleBtn = document.getElementById("toggle-theme");
toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
});
